const SOURCE_NOTE = "These statements are not official Ministry text. BC publishes matrices and quick scales, not Can-Do statements. Each line below is a plain-language paraphrase of a Secondary (8-12) descriptor from the ELL Standards 2017, printed beside its source so the wording can be checked against the original.";

const ALIGNMENT = {
  level: "Expanding (3), working toward Consolidating (4)",
  lever: "Looking back on a full year of work, selecting evidence of growth, writing a reflective essay that proves its claims, and advocating for yourself in a conference.",
  domains: [
    { name: "Writing", pages: "ELL Standards 2017, Secondary (8-12) Writing matrix",
      rows: [
        {can:"I can write a reflective essay that claims, proves, and admits with evidence from my own work.",src:"Expanding, Form: produce a range of personal, informational and some literary genres. Meaning: express a focused idea with some elaboration for an identified purpose and audience.",lessons:"L6, L7, L8"},
        {can:"I can select and annotate my own work to prove a specific skill.",src:"Expanding, Strategies: use frameworks and models to produce and revise text; use pre-writing plans.",lessons:"L2, L5"},
        {can:"I can open a reflection on a specific moment rather than a general statement.",src:"Moving from Expanding \u201Ceffective introduction & predictable conclusion\u201D toward Consolidating \u201Ceffective introduction, clear middle & conclusion with a growing sense of voice.\u201D",lessons:"L6"},
        {can:"I can name what is still hard and set a next step that names a skill.",src:"Expanding, Conventions: edit and revise text for meaning and word choice. Strategies: use self-assessment to monitor and improve.",lessons:"L8, L12"},
        {can:"I can revise my essay against a rubric so every claim has pointed evidence.",src:"Expanding, Strategies/Conventions: edit and revise for meaning; use frameworks to produce and revise text.",lessons:"L9"},
        {can:"I can write an annotation that names a skill and points to where it shows.",src:"Expanding, Meaning: express opinions with some rationale for an identified purpose.",lessons:"L2, L5"},
      ]},
    { name: "Reading", pages: "ELL Standards 2017, Secondary (8-12) Reading matrix",
      rows: [
        {can:"I can read my own earlier work and name what it shows about my abilities at that time.",src:"Expanding, Response & Analysis: express opinions with some rationale; make logical connections to self or other texts.",lessons:"L1, L3"},
        {can:"I can compare an early piece and a later piece and name the specific change.",src:"Moving from Expanding \u201Cidentify the purpose & discriminating features of basic genres\u201D toward Consolidating \u201Cdescribe & analyze main ideas with some insight.\u201D",lessons:"L2, L7"},
        {can:"I can read a model reflective essay for its craft moves, not just its content.",src:"Expanding, Comprehension: identify some simple literary techniques. Response: express opinions with rationale.",lessons:"L4"},
        {can:"I can identify a craft move in a model and use it in my own reflective essay.",src:"Consolidating, Style: use some clear and varied language; a growing sense of voice and tone appropriate to purpose.",lessons:"L4, L6"},
        {can:"I can read an unseen short essay and identify its claim and how it is supported.",src:"Expanding, Comprehension: understand explicit information. Strategies: use predicting, inferencing, contextual clues.",lessons:"L4 (test)"},
        {can:"I can read my portfolio as a whole and describe the trajectory it shows.",src:"Expanding, Response & Analysis: make logical connections to self or other texts supported by reasons.",lessons:"L3, L5"},
      ]},
    { name: "Oral Language", pages: "ELL Standards 2017, Secondary (8-12) Oral Language matrix",
      rows: [
        {can:"I can present my portfolio to my teacher and explain my growth with evidence.",src:"Moving from Expanding \u201Cpresent information & ideas to a familiar audience\u201D toward Consolidating \u201Cpresent with some coherence and organization.\u201D",lessons:"L10, L11"},
        {can:"I can speak from notes and point to my portfolio when I lose my words.",src:"Expanding, Use (expressive): use strategies including circumlocution to sustain communicative tasks.",lessons:"L10, L11"},
        {can:"I can respond to a placement recommendation with a reason, not just a nod.",src:"Expanding, Use (expressive): express agreement and disagreement; use active listening and clarifying questions.",lessons:"L11"},
        {can:"I can name my honest weakness out loud and set a next step.",src:"Expanding, Meaning (expressive): express and connect ideas and some supporting details.",lessons:"L10, L11"},
        {can:"I can ask a real follow-up question when I do not understand something.",src:"Expanding, Use (expressive): seek clarification by asking questions.",lessons:"L11"},
        {can:"I can listen to feedback and respond to what was actually said.",src:"Expanding, Use (receptive): use active listening; understand the main ideas and some details of spoken texts.",lessons:"L11"},
      ]},
  ],
  caution: "Two limits. First, one unit does not move a student between proficiency levels. Second, a reflective unit measures self-assessment and metacognition \u2014 whether the student can SEE their own growth \u2014 as much as the growth itself. A student whose writing grew modestly but who can name exactly what changed and why is demonstrating Expanding-level self-assessment.",
};

const ORAL_RECORD = {
  title: "Oral Language Evidence Record",
  subtitle: "Unit 10 \u00B7 observational \u00B7 not marked",
  intro: "This unit ends in a one-on-one conference, which is the richest single oral-evidence event of the year. But paired discussion runs from Lesson 1 \u2014 use this sheet for the ongoing talk and the conference rubric for the conference itself.",
  howToUse: [
    "Aim for five or six students per lesson in the paired discussion. Rotate.",
    "Record what you observed, not a level. Levels are decided across accumulated evidence.",
    "The conference (Lesson 11) is the clearest evidence of structured, advocated speech. Make sure every student is recorded.",
    "A blank is information. A student with no oral evidence by Lesson 8 is telling you something.",
  ],
  columns: [
    ["Explaining a choice","Gave a reason for selecting or omitting a piece, not just a preference."],
    ["Sustaining","Kept a discussion going: asked a clarifying question, answered one, or described around a missing word."],
    ["Self-assessing","Named a strength or weakness in their own work with evidence, not just a feeling."],
    ["Listening","Responded to what a partner or teacher actually said, not to what they expected."],
  ],
  lessonTasks: [
    ["L1","Name one strong and one uncertain piece; partner says whether they agree."],
    ["L2","Read an annotation aloud; partner says whether it names a skill and points to evidence."],
    ["L3","Describe the shape of your year (leap, plateau, turning point); partner asks about any unexplained part."],
    ["L4","Name one move from the model you will borrow; partner says where it would fit."],
    ["L5","Walk through your portfolio sequence; partner asks about any gap or redundancy."],
    ["L6","Read your opening; partner says where they think the essay is going."],
    ["L7","Read one body paragraph; partner says whether the before-and-after is convincing."],
    ["L8","Read your ending; partner says whether the weakness is specific."],
    ["L9","Swap essays and mark one claim needing stronger proof; give a suggestion."],
    ["L10","Mock conference: deliver your three points; partner asks a follow-up."],
    ["L11","Real conference with the teacher. Record evidence per student."],
    ["L12","Read your closing line; partner says whether it sounds like you."],
  ],
};

module.exports = { ALIGNMENT, ORAL_RECORD, SOURCE_NOTE };
