// ELL 3 — Unit 10 (June) — "Looking Back, Moving Forward": the final unit.
// Students assemble a portfolio from U1–U9, write a reflective essay proving
// their growth with evidence from their own work, and present it in a
// student-teacher conference that carries the placement recommendation.
// This is the unit where a year becomes visible.

const UNIT = {
  course: "ELL3",
  code: "U10",
  num: 10,
  month: "June",
  title: "Looking Back, Moving Forward",
  subtitle: "Your Portfolio, Your Reflection, Your Next Step",
  composition: "A reflective essay on your growth as a reader and writer, supported by evidence from your own work",
};

const ACCENTS = [
  "1565C0", "0F8A8A", "2E9E5B", "C77800", "C0504D", "6A4C93",
  "1565C0", "0F8A8A", "2E9E5B", "C77800", "C0504D", "6A4C93",
];

const LESSONS = [
  {
    n: 1, ytPart: "C",
    title: "The Year on the Table",
    slug: "TheYearOnTheTable",
    warmup: [
      "If you had to show one piece of work from this year to prove you had improved, which would it be and why?",
      "What is the difference between saying you got better and showing where?",
    ],
    goals: [
      "Survey everything you have made this year across all nine units",
      "Begin sorting your work into stronger and weaker pieces",
      "Set up the Portfolio Notebook that carries the whole unit",
    ],
    vocab: [
      ["portfolio", "a collection of your work gathered to show your abilities"],
      ["survey", "to look over everything before choosing"],
      ["reflect", "to look back and draw meaning from what you did"],
      ["evidence", "proof you can point to"],
      ["growth", "a change for the better over time"],
      ["artifact", "a piece of work kept as evidence"],
      ["select", "to choose with a reason"],
      ["annotate", "to add a note explaining why something matters"],
      ["criteria", "the standards used to judge quality"],
      ["representative", "showing what is typical of your ability"],
    ],
    teach1: {
      title: "A portfolio is not a folder",
      points: [
        "A folder holds everything. A portfolio holds what you chose and why you chose it.",
        "The choosing is the skill. Anyone can keep their work; selecting the right pieces takes judgment.",
        "Each piece you include must earn its place with a reason, not just be there because you liked it.",
        "Your portfolio tells a story: where you started, what changed, and where you are now.",
      ],
    },
    teach2: {
      title: "Lay it all out first",
      points: [
        "Before you select, survey. Gather every piece you still have from every unit.",
        "Do not judge yet. Just see what is there. Some pieces you forgot will surprise you.",
        "Sort into rough piles: strongest, weakest, and uncertain. The uncertain pile is the interesting one.",
        "In your Portfolio Notebook, list every piece you found, unit by unit. This is your inventory.",
      ],
    },
    examples: [
      "Strong piece: my Unit 5 essay, because the opening does its job without announcing.",
      "Weak piece: my Unit 2 worksheet, because I filled it in but did not think about it.",
      "Uncertain: my Unit 8 defence paragraph. I thought it was good then but I am not sure now.",
    ],
    practice: {
      instr: "From your gathered work, name one piece in each category and say why in one sentence.",
      items: [
        "Name your strongest piece and say what it does well.",
        "Name your weakest piece and say what is missing.",
        "Name one uncertain piece and say what makes you unsure.",
        "Which pile has the most pieces in it?",
      ],
    },
    speaking: {
      instr: "In pairs, show your partner one strong piece and one uncertain piece. Your partner says whether they agree with your judgment and why.",
      prompts: [
        "This is my strongest piece because ____.",
        "I am not sure about this one because ____.",
        "I agree / disagree because ____.",
      ],
    },
    yourturn: {
      instr: "In your Portfolio Notebook, write your full inventory: every piece, unit by unit, marked S (strong), W (weak), or ? (uncertain).",
    },
    exit: [
      "How many pieces did you find across the year?",
      "What surprised you when you laid it all out?",
    ],
  },

  {
    n: 2, ytPart: "C",
    title: "What Counts as Evidence",
    slug: "WhatCountsAsEvidence",
    warmup: [
      "If someone said they were a good cook, what would convince you \u2014 their word, or the meal?",
      "How is showing your growth different from describing your growth?",
    ],
    goals: [
      "Distinguish a claim from evidence",
      "Choose portfolio pieces that prove something, not just fill space",
      "Write an annotation that names what a piece proves",
    ],
    vocab: [
      ["claim", "a statement you say is true"],
      ["prove", "to show a claim is true with something you can point to"],
      ["annotation", "a note explaining why a piece is in the portfolio"],
      ["specific", "exact and particular, not general"],
      ["vague", "unclear; could mean almost anything"],
      ["demonstrate", "to show by doing, not by saying"],
      ["justify", "to give a reason that holds up"],
      ["compare", "to set two things side by side to see a difference"],
      ["before and after", "two versions showing change over time"],
      ["draft", "an earlier version of a piece of writing"],
    ],
    teach1: {
      title: "A claim without evidence is just a wish",
      points: [
        "\u201CI improved\u201D is a claim. \u201CIn September I announced my topic; in May I opened on a moment\u201D is evidence.",
        "Evidence points to a place. If you cannot point, it is not evidence yet.",
        "The strongest portfolio evidence is a before-and-after: an early piece beside a later one.",
        "A single good piece proves you can do something now. A pair proves you changed.",
      ],
    },
    teach2: {
      title: "Writing an annotation that earns the piece its place",
      points: [
        "Every portfolio piece gets one annotation: what it proves about your growth.",
        "\u201CThis is my best work\u201D is not an annotation. It names no skill and no change.",
        "\u201CThis piece shows I can end without explaining, which I could not do in Unit 2\u201D is.",
        "The annotation does the work of the portfolio. Without it, the piece is just a page.",
      ],
    },
    examples: [
      "Weak annotation: This is a good essay I wrote in Unit 7.",
      "Strong annotation: This essay opens on a moment, not a topic. Compare my Unit 1 opening, which announced what the essay was about.",
      "Paired evidence: Unit 3 draft (announced the topic) beside Unit 9 draft (opened on a scene). The change is in the first two lines.",
    ],
    practice: {
      instr: "Write an annotation for one of your strong pieces. It must name a skill and point to where it shows.",
      items: [
        "Name the skill the piece demonstrates.",
        "Point to the exact place in the piece where it shows.",
        "If possible, name an earlier piece where that skill was missing.",
      ],
    },
    speaking: {
      instr: "In pairs, read your annotation aloud. Your partner says whether it names a skill, points to evidence, and would convince someone who had not read the piece.",
      prompts: [
        "This piece proves I can ____, and you can see it where ____.",
        "Does my annotation name a skill or just say it is good?",
        "What would make this annotation more convincing?",
      ],
    },
    yourturn: {
      instr: "Choose three pieces for your portfolio and write a one-sentence annotation for each. Each must name a skill and point to where it shows.",
    },
    exit: [
      "What is the difference between a claim and evidence?",
      "Read one of your annotations. Does it point to a place?",
    ],
  },

  {
    n: 3, ytPart: "C",
    title: "The Shape of a Year",
    slug: "TheShapeOfAYear",
    warmup: [
      "If you drew a line from your first piece of writing to your most recent, what would the line look like \u2014 straight up, flat, or something else?",
      "Growth is rarely smooth. When did you get stuck, and what unstuck you?",
    ],
    goals: [
      "Map your growth across the year with evidence, not just feeling",
      "Identify your biggest leap and your longest plateau",
      "Record the shape of the year in the Portfolio Notebook",
    ],
    vocab: [
      ["trajectory", "the path something follows over time"],
      ["plateau", "a period where nothing seems to change"],
      ["leap", "a sudden, visible jump forward"],
      ["stagnate", "to stop growing or changing"],
      ["momentum", "the force that keeps progress moving"],
      ["turning point", "the moment something changed direction"],
      ["setback", "a step backward or a period of struggle"],
      ["pattern", "something that repeats across time"],
      ["honest", "truthful, including about what is still hard"],
      ["timeline", "events placed in order along a line"],
    ],
    teach1: {
      title: "Name the shape, not just the direction",
      points: [
        "\u201CI got better\u201D names a direction. It does not name the shape.",
        "Was there a unit where something clicked? That is a leap. Point to the piece that shows it.",
        "Was there a stretch where your work stayed flat? That is a plateau. Name what held you there.",
        "The reflection you write later needs this shape. Map it now so you are not guessing then.",
      ],
    },
    teach2: {
      title: "Turning points have causes",
      points: [
        "A turning point is not random. Something happened: a lesson, a text, a comment, a failure.",
        "Name the cause, not just the moment. \u201CUnit 6 was where it changed\u201D is not enough.",
        "\u201CIn Unit 6 I read a story that ended on an object, and I tried it, and it worked\u201D names the cause.",
        "A setback has a cause too. Naming it honestly is evidence of self-knowledge, not weakness.",
      ],
    },
    examples: [
      "Leap: Unit 5, when I stopped announcing my topic and started opening on a scene. Cause: the mentor text showed me what it looked like.",
      "Plateau: Units 3 and 4. I knew what to do but my writing did not change because I was not revising.",
      "Turning point: the peer feedback in Unit 9. Someone pointed out my endings always explained, and I heard it.",
    ],
    practice: {
      instr: "On the worksheet, map your year: mark each unit as a leap, plateau, or steady progress, and name the cause.",
      items: [
        "Mark your biggest leap. What caused it?",
        "Mark your longest plateau. What held you there?",
        "Mark one turning point with its cause.",
      ],
    },
    speaking: {
      instr: "In pairs, describe the shape of your year. Your partner asks about any leap or plateau you cannot explain.",
      prompts: [
        "My biggest leap was in Unit ____ because ____.",
        "I was stuck during ____ because ____.",
        "The thing that changed it was ____.",
      ],
    },
    yourturn: {
      instr: "In your Portfolio Notebook (Checkpoint 1), write the shape of your year: your biggest leap, your longest plateau, and one turning point, each with its cause.",
    },
    exit: [
      "What was your biggest leap and what caused it?",
      "Why is naming a plateau honest rather than negative?",
    ],
  },

  {
    n: 4, ytPart: "C",
    title: "Reading the Mentor Reflection",
    slug: "ReadingTheMentorReflection",
    warmup: [
      "You are about to read a reflective essay by a student looking back on a year. What makes a reflection convincing rather than just nice?",
      "What is the difference between a reflection and a summary of what you did?",
    ],
    goals: [
      "Read a model reflective essay for its craft, not just its content",
      "Identify the moves that make a reflection prove its claims",
      "Note moves you can borrow for your own reflection",
    ],
    vocab: [
      ["reflective essay", "a piece of writing that looks back on experience to draw meaning"],
      ["model", "an example to study and learn from"],
      ["self-knowledge", "understanding your own strengths and weaknesses"],
      ["tone", "the attitude or feeling in the writing"],
      ["candid", "open and honest, not hiding the hard parts"],
      ["generalize", "to make a broad statement without specific support"],
      ["anchor", "to tie a claim to a specific place or moment"],
      ["structure", "how the parts of a text are arranged"],
      ["borrow", "to take a technique and use it in your own way"],
      ["voice", "the personality that comes through in writing"],
    ],
    teach1: {
      title: "A reflection is not a thank-you speech",
      points: [
        "\u201CThis year was amazing and I learned so much\u201D is a thank-you speech. It proves nothing.",
        "A reflection names what changed, points to where, and says what still needs work.",
        "The model essay does three things: it claims, it proves, and it admits what is still hard.",
        "Notice how the writer anchors every claim to a specific piece of work. That is the skill.",
      ],
    },
    teach2: {
      title: "Moves to borrow from the model",
      points: [
        "The writer opens on a specific early failure, not on a general statement about the year.",
        "Each body paragraph picks one skill, names the before, names the after, and points to the evidence.",
        "The ending names one thing still hard \u2014 honestly, without apologizing \u2014 and sets a next step.",
        "The tone is candid. It does not perform gratitude or pretend everything is resolved.",
      ],
    },
    examples: [
      "Claim-and-proof from the model: \u201CI can defend a form now. My Unit 9 defence names what a reader would lose.\u201D",
      "Honest admission: \u201CMy endings still explain too much. You can see it in the last line of my Unit 7 essay.\u201D",
      "Next step: \u201CI would work on trusting the reader, because I still reach for the explanation.\u201D",
    ],
    practice: {
      instr: "Read the mentor essay. For each claim the writer makes, find the evidence they point to.",
      items: [
        "Find one claim the writer anchors to a specific piece.",
        "Find the honest admission. What makes it honest rather than self-critical?",
        "Find the next step. Does it name a skill, not just a feeling?",
      ],
    },
    speaking: {
      instr: "In pairs, name one move from the model you could borrow for your own reflection. Say where you would use it.",
      prompts: [
        "The writer ____ and it works because ____.",
        "I could borrow that by ____ in my own reflection.",
        "The model's honest admission made it more convincing because ____.",
      ],
    },
    yourturn: {
      instr: "Write two craft moves you will borrow from the model for your own reflective essay, and where you will use each one.",
    },
    exit: [
      "What is one move from the model that made a claim convincing?",
      "How is a reflective essay different from a summary of the year?",
    ],
  },

  {
    n: 5, ytPart: "C",
    title: "Choosing Your Pieces",
    slug: "ChoosingYourPieces",
    warmup: [
      "You have surveyed, sorted, and mapped the year. How many pieces should a portfolio hold \u2014 everything, or a few that prove something?",
      "What makes five well-chosen pieces stronger than twenty unchosen ones?",
    ],
    goals: [
      "Select your final portfolio pieces with clear reasons",
      "Ensure your selection tells the story of your year, not just your best day",
      "Write final annotations for each selected piece",
    ],
    vocab: [
      ["curate", "to select and arrange with purpose"],
      ["purpose", "the reason behind a choice"],
      ["range", "variety; showing different abilities, not the same one five times"],
      ["sequence", "a deliberate order that tells a story"],
      ["omit", "to leave out on purpose"],
      ["justify", "to give a reason that holds up to questioning"],
      ["redundant", "repeating what another piece already shows"],
      ["complement", "to add something the other pieces do not cover"],
      ["final", "the version that goes forward; the one you stand behind"],
      ["submission", "the work you hand in to be assessed"],
    ],
    teach1: {
      title: "Five to seven pieces, not twenty",
      points: [
        "A portfolio that holds everything says you could not choose. Choosing is the skill.",
        "Aim for five to seven pieces that together show your range and your growth.",
        "Each piece should prove something different. Two pieces proving the same skill is redundant.",
        "The set should include at least one early piece and one late piece, so the growth is visible.",
      ],
    },
    teach2: {
      title: "Sequence matters",
      points: [
        "Put your pieces in an order that tells the story of the year.",
        "Chronological usually works, but you might lead with your strongest and close with your most honest.",
        "The last piece in the portfolio should be recent and should show who you are now.",
        "Each annotation carries the reader from one piece to the next: this is what I could do, and this is what changed.",
      ],
    },
    examples: [
      "Five-piece set: early opening (Unit 2) \u2192 first strong body (Unit 5) \u2192 first defence (Unit 8) \u2192 borrowed move (Unit 9) \u2192 final essay (Unit 9).",
      "Why this order: it walks the reader through the year, and each piece picks up where the last left off.",
      "What was omitted: three worksheets that repeated the same skill, and one piece I liked but that proved nothing new.",
    ],
    practice: {
      instr: "Choose your final pieces and arrange them. Write one sentence for each explaining why it is in.",
      items: [
        "Choose your opening piece. Why does it come first?",
        "Choose your closing piece. Why does it come last?",
        "Name one piece you are leaving out and say why.",
      ],
    },
    speaking: {
      instr: "In pairs, walk your partner through your sequence. They ask about any piece that seems redundant or any gap that seems missing.",
      prompts: [
        "My portfolio goes: ____, then ____, then ____.",
        "I left out ____ because ____.",
        "Is there a gap between ____ and ____?",
      ],
    },
    yourturn: {
      instr: "In your Portfolio Notebook, write your final selection: each piece in order, with its annotation. This is the set that goes forward.",
    },
    exit: [
      "How many pieces are in your portfolio and why that number?",
      "What does your closing piece prove that the others do not?",
    ],
  },

  {
    n: 6, ytPart: "C",
    title: "The Reflection Opens",
    slug: "TheReflectionOpens",
    warmup: [
      "You wrote openings all year. How should a reflective essay open \u2014 on a general statement about the year, or on something specific?",
      "What did the model essay open on, and why did it work?",
    ],
    goals: [
      "Draft the opening of your reflective essay",
      "Open on a specific moment, not a general claim about the year",
      "Set up the claim the rest of the essay will prove",
    ],
    vocab: [
      ["opening", "the first part of a text; how it begins"],
      ["specific", "exact and particular"],
      ["general", "broad; not pointing to anything exact"],
      ["anchor", "to tie a claim to a specific place or moment"],
      ["set up", "to prepare the reader for what comes next"],
      ["contrast", "showing two different things to highlight the gap"],
      ["thesis", "the main point the essay will prove"],
      ["tone", "the attitude or feeling that comes through"],
      ["candid", "open and honest"],
      ["engage", "to hold the reader's attention from the start"],
    ],
    teach1: {
      title: "Open on September, not on a feeling",
      points: [
        "\u201CThis year I learned a lot\u201D opens on a feeling. It could be anyone's essay.",
        "Open on a specific early moment \u2014 your first piece, your first confusion, your first failure.",
        "The reader needs to see where you started to believe where you ended up.",
        "The opening is a before picture. The rest of the essay is the after.",
      ],
    },
    teach2: {
      title: "Set up the claim without stating it yet",
      points: [
        "Show the gap between then and now without saying \u201CI improved.\u201D",
        "The reader should feel the distance by the end of the opening, not be told it.",
        "A line from your early work, quoted, is the strongest opening move for this essay.",
        "The model essay did this: opened on a failure, then let the reader watch it change.",
      ],
    },
    examples: [
      "Weak: This year in ELL 3 I learned many things about writing. Strong: In September I started an essay with \u201CThis essay is about\u201D and I did not know there was another way.",
      "Weak: I have grown as a writer. Strong: My first paragraph had five comparisons in it and every one was a clich\u00e9.",
      "Setup: the opening shows September; paragraph two will show May. The gap speaks.",
    ],
    practice: {
      instr: "Draft your opening. It must begin on a specific early moment and set up the distance the essay will prove.",
      items: [
        "Start with one specific thing from your early work.",
        "Do not say you improved. Let the reader see where you started.",
        "Read it back: does it sound like only you could have written it?",
      ],
    },
    speaking: {
      instr: "In pairs, read only your opening aloud. Your partner says where they think the essay is going and whether they want to keep reading.",
      prompts: [
        "My opening starts at ____.",
        "After hearing that, I expect the essay will ____.",
        "That opening makes me want to / not want to keep reading because ____.",
      ],
    },
    yourturn: {
      instr: "Draft your reflective essay opening. In your Portfolio Notebook (Checkpoint 2), note the early moment you used and what it sets up.",
    },
    exit: [
      "What specific early moment does your opening begin on?",
      "Why is it stronger to show September than to say you improved?",
    ],
  },

  {
    n: 7, ytPart: "C",
    title: "Building the Case",
    slug: "BuildingTheCase",
    warmup: [
      "A lawyer does not say the client is innocent and sit down. They present evidence, piece by piece. How is a reflective essay the same?",
      "You have portfolio pieces with annotations. How do they become paragraphs in an essay?",
    ],
    goals: [
      "Draft the body of your reflective essay with evidence from your portfolio",
      "Give each body paragraph one skill, one before, one after, and one pointed piece of evidence",
      "Keep the essay proving, not just describing",
    ],
    vocab: [
      ["body", "the middle section of an essay that does the proving"],
      ["develop", "to build a point out with detail and evidence"],
      ["paragraph", "a group of sentences doing one job"],
      ["skill", "a specific ability you can name and demonstrate"],
      ["before", "what you could do earlier, shown with evidence"],
      ["after", "what you can do now, shown with evidence"],
      ["transition", "a sentence connecting one paragraph to the next"],
      ["proportion", "how much space each part gets"],
      ["discipline", "staying on one point per paragraph, not wandering"],
      ["convincing", "strong enough to make a reader believe your claim"],
    ],
    teach1: {
      title: "One paragraph, one skill, one proof",
      points: [
        "Each body paragraph picks one thing you can now do. Not three, not \u201Cmany things.\u201D One.",
        "Name the before: what the early piece shows. Name the after: what the recent piece shows.",
        "Point to the exact place in each piece. A paragraph without a pointed reference is a claim, not proof.",
        "Two or three body paragraphs are enough. More dilutes rather than strengthens.",
      ],
    },
    teach2: {
      title: "Transitions carry the story forward",
      points: [
        "The first body paragraph might be \u201CThe first thing that changed was ___.\u201D",
        "The second: \u201COnce that was in place, something else shifted.\u201D",
        "Each paragraph should feel like a step on the timeline you mapped in Lesson 3.",
        "The transitions carry the reader through your year, not just through your list of skills.",
      ],
    },
    examples: [
      "One skill proven: \u201CI can open on a moment now. In Unit 2 I opened with \u2018This essay is about.\u2019 In Unit 9 I opened with the coat on the chair.\u201D",
      "The \u201Cbefore\u201D pointed: the first line of the Unit 2 essay, quoted.",
      "The \u201Cafter\u201D pointed: the first line of the Unit 9 essay, quoted. The gap speaks for itself.",
    ],
    practice: {
      instr: "Draft one body paragraph. It must name one skill, quote or point to a before, and quote or point to an after.",
      items: [
        "Name the skill in one sentence.",
        "Point to the before: which piece, which place?",
        "Point to the after: which piece, which place?",
      ],
    },
    speaking: {
      instr: "In pairs, read your body paragraph. Your partner says whether the before and after are specific enough to be convincing.",
      prompts: [
        "The skill I am proving is ____.",
        "My before is ____ and my after is ____.",
        "Is the gap visible, or do I need to be more specific?",
      ],
    },
    yourturn: {
      instr: "Draft the full body of your reflective essay: two or three paragraphs, each proving one skill with a before-and-after from your portfolio.",
    },
    exit: [
      "How many skills does your body prove, and are they each in their own paragraph?",
      "Point to one before-and-after. Would it convince someone who does not know you?",
    ],
  },

  {
    n: 8, ytPart: "C",
    title: "The Honest Ending",
    slug: "TheHonestEnding",
    warmup: [
      "The model essay ended on what is still hard, not on what was achieved. Why is that a stronger ending?",
      "What is the difference between an honest weakness and self-criticism?",
    ],
    goals: [
      "Draft the ending of your reflective essay with honesty and a next step",
      "Name what is still hard with evidence, not apology",
      "Set one real next step for your growth as a reader and writer",
    ],
    vocab: [
      ["ending", "the closing part of a text"],
      ["honest", "truthful, including about what is still hard"],
      ["weakness", "something you have not yet mastered"],
      ["self-criticism", "attacking yourself rather than naming what to work on"],
      ["next step", "one specific thing you would work on next"],
      ["resolve", "to settle or complete"],
      ["open", "left unfinished on purpose; showing the work continues"],
      ["humility", "knowing your limits without being defeated by them"],
      ["forward", "looking ahead, not only back"],
      ["earn", "to gain through effort, not by claiming"],
    ],
    teach1: {
      title: "End on what is still hard",
      points: [
        "An ending that claims everything is resolved is not believable. Growth does not stop in June.",
        "Name one thing that is still hard. Point to where it shows in your recent work.",
        "\u201CMy endings still explain too much; you can see it in my last paragraph\u201D is honest and specific.",
        "This is not self-criticism. It is self-knowledge, and it is the hardest thing in the essay to write well.",
      ],
    },
    teach2: {
      title: "Set one next step, not five",
      points: [
        "One next step is believable. Five is a wish list.",
        "The next step should name a skill, not a feeling. \u201CI will try harder\u201D names nothing.",
        "\u201CI would work on trusting the reader to reach the meaning without me explaining it\u201D names a skill.",
        "The ending of your essay is also the beginning of whatever comes next. Leave it open on purpose.",
      ],
    },
    examples: [
      "Honest ending: \u201CMy openings are better. My endings are not. The last line of my Unit 9 essay still explains, and I know it.\u201D",
      "Next step: \u201CNext year I would practise ending on an image or an action and walking away from the explanation.\u201D",
      "Self-criticism to avoid: \u201CI am bad at endings and I always will be.\u201D That is defeat, not honesty.",
    ],
    practice: {
      instr: "Draft your ending. It must name one weakness with evidence and one next step with a specific skill.",
      items: [
        "Name what is still hard and point to where it shows.",
        "Write your next step as a skill, not a wish.",
        "Read it back: does it sound honest or does it sound like giving up?",
      ],
    },
    speaking: {
      instr: "In pairs, read your ending. Your partner says whether the weakness is specific and the next step is a skill.",
      prompts: [
        "What is still hard for me is ____, and you can see it where ____.",
        "My next step is ____.",
        "Does that sound honest or does it sound like I am apologizing?",
      ],
    },
    yourturn: {
      instr: "Draft your full ending: one weakness with evidence, one next step naming a skill, and a closing line that leaves the essay open.",
    },
    exit: [
      "What is one thing still hard, with evidence?",
      "What is your next step, named as a skill?",
    ],
  },

  {
    n: 9, ytPart: "C",
    title: "Revising the Whole",
    slug: "RevisingTheWhole",
    warmup: [
      "You have a full draft now. What is the one thing most likely to be wrong with it?",
      "Is revising the reflection different from revising the essays you wrote earlier this year?",
    ],
    goals: [
      "Revise your reflective essay against the rubric as a whole piece",
      "Check that every claim is proven and every proof is pointed",
      "Prepare the essay and portfolio for the conference",
    ],
    vocab: [
      ["revise", "to change what a draft does or means"],
      ["rubric", "a chart of criteria and levels used to mark work"],
      ["coherence", "the sense that the parts belong together"],
      ["proof", "evidence that a claim is true"],
      ["pointed", "referring to a specific place, not a general idea"],
      ["gap", "a place where something is missing"],
      ["tighten", "to remove what does not earn its place"],
      ["flow", "the sense of movement from one part to the next"],
      ["final", "the version that goes forward"],
      ["polish", "to make the last small improvements"],
    ],
    teach1: {
      title: "Revise the claims, not the commas",
      points: [
        "Read once for whether every claim has evidence pointing to a place. That is the first pass.",
        "Mark any claim that sounds good but has no pointed proof. That is where the essay is weakest.",
        "Check that your before-and-after pairs are real pairs, not two separate points.",
        "The rubric asks: is the growth proven, or only described? Read your essay as the reader.",
      ],
    },
    teach2: {
      title: "Tighten and prepare",
      points: [
        "Cut any sentence that describes a feeling without naming a cause or a place.",
        "Check your transitions: does each paragraph pick up where the last left off?",
        "Read the ending: does the weakness feel honest, or does it feel like a performance?",
        "Your essay and your portfolio go to the conference together. They should tell the same story.",
      ],
    },
    examples: [
      "Revision: \u201CI removed a sentence that said I was proud of my growth. It did not name anything.\u201D",
      "Gap found: \u201CMy second paragraph claims I can use evidence, but it does not quote any of my work.\u201D",
      "Tightened: \u201CI cut my closing paragraph from eight lines to four. The extra four were explaining what I had already shown.\u201D",
    ],
    practice: {
      instr: "Do one full revision pass against the rubric. Mark every claim that has no pointed proof.",
      items: [
        "Read for claims without evidence. How many did you find?",
        "Fix the weakest one by adding a pointed reference.",
        "Read the ending. Is the weakness specific or vague?",
      ],
    },
    speaking: {
      instr: "In pairs, swap essays and mark one claim your partner made that needs stronger proof. Give it back with one specific suggestion.",
      prompts: [
        "This claim needs proof: ____.",
        "You could strengthen it by pointing to ____.",
        "Your ending is honest / needs to be more specific because ____.",
      ],
    },
    yourturn: {
      instr: "Revise your full essay against the rubric. In your Portfolio Notebook (Checkpoint 3), note the one revision that most improved the essay.",
    },
    exit: [
      "What was the weakest claim in your draft and how did you fix it?",
      "Is your essay and portfolio ready for the conference?",
    ],
  },

  {
    n: 10, ytPart: "C",
    title: "Preparing for the Conference",
    slug: "PreparingForTheConference",
    warmup: [
      "In a few days you will sit with your teacher and talk about your year. What do you want to say that the essay does not already cover?",
      "How is a conference different from a presentation?",
    ],
    goals: [
      "Prepare to speak about your growth and your portfolio in a one-on-one conference",
      "Know the three things you must cover: your best evidence, your honest weakness, your next step",
      "Practise speaking from your portfolio, not from a script",
    ],
    vocab: [
      ["conference", "a one-on-one meeting to discuss your work"],
      ["placement", "a recommendation for which level comes next"],
      ["advocate", "to speak up for yourself with reasons"],
      ["prepared", "ready, with your materials and your points"],
      ["listen", "to hear what the teacher says and respond to it"],
      ["question", "something the teacher may ask that you should think about in advance"],
      ["nervous", "feeling worried about something that is coming"],
      ["genuine", "real and honest, not performed"],
      ["brief", "short and to the point"],
      ["recommendation", "a suggestion about what should come next"],
    ],
    teach1: {
      title: "The conference is a conversation, not a speech",
      points: [
        "You are not presenting. You are sitting with your teacher and talking about your year.",
        "Bring your portfolio open to your strongest piece. You will walk through it together.",
        "Cover three things: your strongest evidence of growth, your honest weakness, and your next step.",
        "The teacher will also share a placement recommendation. Listen and respond, do not just nod.",
      ],
    },
    teach2: {
      title: "What to do when you are nervous or stuck",
      points: [
        "It is normal to be nervous. The portfolio is your anchor \u2014 if you lose your words, point to a piece.",
        "If you do not understand a question, ask the teacher to rephrase it. That is a strength, not a failure.",
        "If you disagree with the placement recommendation, say so with a reason. That is what advocating means.",
        "The conference is short. Prepare more than you need, but expect to use only three or four minutes of it.",
      ],
    },
    examples: [
      "Opening: \u201CThe piece I want to start with is my Unit 9 essay, because this is where I can see the change.\u201D",
      "Honest moment: \u201CThe thing I am still working on is my endings. I know they explain too much.\u201D",
      "Responding to placement: \u201CI think I am ready for that level because ___.\u201D or \u201CCan you tell me what I would need to work on to get there?\u201D",
    ],
    practice: {
      instr: "Write your three conference points as short notes (not a script). Practise saying each one aloud from the note.",
      items: [
        "Your strongest evidence: which piece, which skill, where it shows.",
        "Your honest weakness: what and where.",
        "Your next step: the skill you would work on.",
      ],
    },
    speaking: {
      instr: "In pairs, do a mock conference. One person is the student, the other listens and asks one follow-up question. Then swap.",
      prompts: [
        "The piece I want to start with is ____.",
        "What is still hard for me is ____.",
        "My next step is ____.",
      ],
    },
    yourturn: {
      instr: "Write your three conference notes on one page. Mark the portfolio piece you will open to. You are ready.",
    },
    exit: [
      "What is the first thing you will say at the conference?",
      "What will you do if you do not understand a question?",
    ],
  },

  {
    n: 11, ytPart: "C",
    title: "The Conference",
    slug: "TheConference",
    warmup: [
      "Today is the conference. Take one breath. You have prepared, you have your portfolio, and you know your three points.",
      "What is one thing you want your teacher to know that they might not see in the essay?",
    ],
    goals: [
      "Conduct your student-teacher conference",
      "Speak about your growth with evidence from your portfolio",
      "Listen to and respond to your placement recommendation",
    ],
    vocab: [
      ["conduct", "to carry out or lead"],
      ["evidence", "proof you can point to"],
      ["respond", "to answer thoughtfully, not just agree"],
      ["advocate", "to speak up for yourself with reasons"],
      ["placement", "a recommendation for which level comes next"],
      ["listen", "to hear and take in what is said"],
      ["self-assess", "to judge your own work honestly"],
      ["feedback", "useful comment on how to improve"],
      ["acknowledge", "to show you have heard and understood"],
      ["close", "to end a meeting clearly"],
    ],
    teach1: {
      title: "Walk in with your portfolio open",
      points: [
        "Open to your strongest piece before you sit down. That is your anchor.",
        "Start with your best evidence of growth. Point to the page.",
        "When the teacher asks a question, answer from the work, not from feelings.",
        "If you lose your words, point to the piece and say what you see there.",
      ],
    },
    teach2: {
      title: "Listen to the placement, then respond",
      points: [
        "The teacher will share a recommendation. Listen to the whole thing before you speak.",
        "If you agree, say what you agree with and why.",
        "If you disagree, say what evidence you think supports a different placement.",
        "If you are unsure, ask what you would need to show to reach the next level. That is a real question.",
      ],
    },
    examples: [
      "Strong opening: \u201CI want to start with my Unit 9 essay. The opening shows what changed.\u201D",
      "Responding: \u201CI agree with that placement because I can see in my portfolio that my reading work is stronger than my writing endings.\u201D",
      "Asking a real question: \u201CWhat would I need to work on over the summer to be ready for the next level?\u201D",
    ],
    practice: {
      instr: "This lesson IS the conference. While you wait for your turn, review your three points and your portfolio one more time.",
      items: [
        "Review your strongest evidence.",
        "Review your honest weakness.",
        "Review your next step.",
      ],
    },
    speaking: {
      instr: "Conduct your conference with the teacher. Students waiting practise with a partner.",
      prompts: [
        "I want to start with ____.",
        "The thing I am most proud of is ____, and you can see it here.",
        "What is still hard for me is ____.",
      ],
    },
    yourturn: {
      instr: "After your conference, write one sentence in your Portfolio Notebook about what the teacher said and one thing you will remember.",
    },
    exit: [
      "What did you learn from the conference that you did not already know?",
      "What was the placement recommendation and do you agree?",
    ],
  },

  {
    n: 12, ytPart: "C",
    title: "What You Made This Year",
    slug: "WhatYouMadeThisYear",
    warmup: [
      "This is the last lesson of the course. Look at your portfolio. What do you see?",
      "If you could say one thing to yourself in September, what would it be?",
    ],
    goals: [
      "Write the final Portfolio Notebook reflection",
      "Submit your portfolio and your reflective essay",
      "Close the course with an honest view of where you are and where you are going",
    ],
    vocab: [
      ["reflection", "looking back to draw meaning from what you did"],
      ["submit", "to hand in finished work"],
      ["close", "to bring something to an end"],
      ["legacy", "what you leave behind"],
      ["transition", "a move from one stage to the next"],
      ["identity", "who you are as a reader and writer"],
      ["voice", "the personality that comes through in your writing"],
      ["agency", "the power to make your own choices"],
      ["capable", "able to do something you could not before"],
      ["continue", "to keep going after this course ends"],
    ],
    teach1: {
      title: "The portfolio reflection is the final mark",
      points: [
        "This is the piece the Portfolio Notebook is assessed on, not the number of entries.",
        "It answers three questions: what can you do now, what is still hard, and what comes next.",
        "Each answer must point to evidence from your portfolio. The pointing is the skill.",
        "A thin reflection with a full portfolio scores lower than a strong reflection with a lean one.",
      ],
    },
    teach2: {
      title: "Close the year, open the next one",
      points: [
        "Your last paragraph is not a goodbye. It is a statement about who you are now as a writer.",
        "Say what you know you can do, and mean it. This is not modesty; it is accuracy.",
        "Say what you will carry forward, not what you will leave behind.",
        "Submit your portfolio and your essay. The course is done. The work continues.",
      ],
    },
    examples: [
      "Final reflection: \u201CI can open on a moment, defend a form, and notice a craft move. I cannot yet trust the reader with my endings.\u201D",
      "Evidence: \u201CThe proof is in my portfolio: Unit 2 opens on an announcement, Unit 9 opens on a coat on a chair.\u201D",
      "Closing: \u201CWhat I carry forward is the habit of looking at my own work the way I learned to look at someone else's.\u201D",
    ],
    practice: {
      instr: "Write your final reflection. Three questions, three answers, three proofs. This is what the Notebook is marked on.",
      items: [
        "What can you do now? Point to the evidence.",
        "What is still hard? Point to where it shows.",
        "What comes next? Name the skill, not the feeling.",
      ],
    },
    speaking: {
      instr: "In pairs, read your closing line aloud. Your partner says whether it sounds like you, not like a speech.",
      prompts: [
        "What I can do now is ____.",
        "What is still hard is ____.",
        "What I carry forward is ____.",
      ],
    },
    yourturn: {
      instr: "Write your final Portfolio Notebook reflection (Checkpoint 4). Submit your portfolio and your reflective essay. The course is done.",
    },
    exit: [
      "What is the one thing you can do now that you could not in September?",
      "What will you carry forward?",
    ],
  },
];

module.exports = { UNIT, LESSONS, ACCENTS };
