// ELL 3 U10 — ONE authored mentor text: a model reflective essay by a fictional student
// looking back on a year of language learning. No second story — this unit reads the
// student's own past work, not new literature. The model is taught closely in L4.

const STORIES = [
  {
    title: "What I Did Not Know I Was Learning",
    slug: "WhatIDidNotKnowIWasLearning",
    blurb: "A model reflective essay. Taught closely in Lesson 4 \u2014 read it for how it proves its claims, not only for what it says.",
    lesson: "Lesson 4",
    paras: [
      "In September I wrote an essay that began with the sentence \u201CThis essay is about my family.\u201D I handed it in and I thought I had done what was asked.",
      "I had. The essay was about my family. It said so, right there, in the first line. But the first line did nothing except tell the reader what was coming, and a reader who already knows what is coming has no reason to keep going.",
      "I did not learn that in September. I learned it in November, when I read a story that opened on a woman standing in a doorway holding a pair of shoes. The story never said what it was about. By the third paragraph I knew anyway, because the shoes and the doorway had already told me.",
      "That was the first thing that changed: I stopped announcing. My next essay opened on my father filling in a form, and the reader did not know where they were going, and they went.",
      "The second thing took longer. In February I was asked to choose between writing a narrative and an essay, and I wrote \u201CI chose narrative because I like stories.\u201D My teacher circled it and wrote \u201Cthat is about you, not the reader.\u201D I did not understand the comment until March, when I wrote a defence that said the reader should feel the moment before they judged it. The difference is that the second sentence is about what happens to the person reading, not about what I prefer.",
      "I cannot point to one lesson where that clicked. It was more like a slow turn, the way a door opens when you lean on it without realising you are leaning.",
      "What I have not learned yet is how to end. Every essay I have written this year closes by explaining what it meant, as though I do not trust the reader to have been there for the whole thing. My teacher says \u201Cend on the coat, not the feeling,\u201D and I know what she means, and I still reach for the explanation every time.",
      "That is my next work. To stop explaining. To put the image down and walk away. It sounds simple and it is the hardest thing in this whole year because it means believing, at the exact moment I am most uncertain, that what I wrote is enough.",
    ],
    vocab: [
      ["announce","to state what you are about to do rather than doing it"],
      ["defence","a reasoned account of why a choice was right"],
      ["claim","a statement you say is true"],
      ["evidence","proof you can point to"],
      ["trust","to believe something will hold without your help"],
      ["explain","to state the meaning of something directly"],
    ],
    questions: {
      literal: [
        "What sentence did the writer begin with in September?",
        "What story changed how the writer thought about openings?",
        "What did the teacher write beside the writer's first defence?",
        "What does the writer say they have not yet learned?",
      ],
      inference: [
        "The writer says the reader \u201Cdid not know where they were going, and they went.\u201D What does this tell you about what a good opening does? Use the text.",
        "Why does the writer include the February defence AND the March defence? What does the pair prove that one alone would not?",
        "The writer compares learning to \u201Ca door that opens when you lean on it without realising you are leaning.\u201D What does this comparison say about how growth happens?",
        "The ending admits a weakness. Does this make the essay more or less convincing? Why?",
      ],
    },
    teacherNotes: {
      heading: "What I Did Not Know I Was Learning \u2014 teacher notes",
      intro: "This is the model reflective essay for the unit. Teach it in Lesson 4 so students can study its craft before writing their own. The essay demonstrates the three things a strong reflection does: it claims a skill, it proves the claim with before-and-after evidence, and it ends on an honest weakness with a named next step. Resist summarising the content; the point is the moves, not the story.",
      points: [
        ["Every claim is anchored","The writer never says \u201CI improved\u201D without pointing to a line. The September opening, the November story, the February and March defences \u2014 each is a specific, quotable place. That is the standard students need to match."],
        ["The before-and-after is the proof","The essay does not just show the good work. It shows the early version beside the later version, and the gap speaks. Students who include only their best piece miss the mechanism."],
        ["The honest ending is the strongest part","The writer names endings as the skill they have not earned. The evidence (\u201Cevery essay closes by explaining\u201D) is specific, and the next step (\u201Cstop explaining\u201D) names the skill. Students tend to end on gratitude or triumph; this essay models how honesty is more convincing than either."],
        ["The tone is candid, not performed","The voice is the writer's own. It does not sound like a speech or a thank-you card. Encourage students to write in their real voice, not in the voice they think a reflection should have."],
      ],
      themes: [
        "Growth often happens before you recognise it.",
        "The hardest skill is the one you can name but not yet do.",
        "Trusting the reader is the same as trusting yourself.",
      ],
      caution: "Students may try to reproduce the content of this essay (openings, defences, endings) rather than its structure (claim, proof, honest admission). Redirect: the skills the model writer names are that writer's skills, not necessarily yours. The structure \u2014 specific before, specific after, honest weakness, named next step \u2014 is what transfers.",
    },
  },
];

module.exports = { STORIES };
