const EXEMPLARS = {
  topic: "Write a reflective essay on your growth as a reader and writer this year, supported by evidence from your own work.",
  note: "These three reflections answer the same task at three levels. All three are grammatically sound. The differences are in whether the growth is described or proven, whether the evidence is pointed or vague, and whether the ending is honest or performed.",
  tiers: [
    { name: "Developing", band: "Emerging to Developing on the essay rubric",
      text: [
        "This year in ELL 3 I learned a lot about writing. I wrote many essays and I got better at all of them. My favourite was the narrative in Unit 9 because I like telling stories. I also learned about figurative language which was very interesting. I think I am a better writer now than I was in September. I would like to keep improving next year and learn even more about English. Thank you to Mr. Reid for a great year.",
      ],
      why: [
        "\u201CI learned a lot\u201D and \u201CI got better\u201D are claims with no evidence. Nothing is pointed to.",
        "\u201CMy favourite was\u201D is a preference, not a skill. It proves nothing about growth.",
        "No before-and-after. The reader cannot see the change because the writer does not show it.",
        "The ending thanks the teacher instead of naming what is still hard. It performs rather than reflects.",
      ]},
    { name: "Proficient", band: "Proficient on the essay rubric",
      text: [
        "In September I started every essay the same way: \u201CThis essay is about.\u201D I did not know there was another option. By Unit 5 I could open on a moment instead of an announcement, and by Unit 9 my opening put the reader in a room before they knew what the essay was about.",
        "The second thing that changed was defending a choice. In Unit 8 I wrote \u201CI chose narrative because I like it,\u201D which my teacher called an admission, not a defence. In Unit 9 I wrote that I chose narrative so the reader would reach the meaning before I stated it. That defence names the reader, not me.",
        "What is still hard is endings. My Unit 9 essay explains in the last line what the whole piece already showed. I know it does and I left it there because I could not find a better way to stop. Next year I want to practise ending on an image and walking away.",
      ],
      why: [
        "Each paragraph picks one skill, names the before (September announcements, the Unit 8 admission), and names the after (Unit 9 opening, Unit 9 defence).",
        "The evidence is pointed: specific units, specific lines, specific changes.",
        "The ending names a real weakness with evidence (\u201Cthe last line explains\u201D) and sets a next step that names a skill.",
        "The tone is candid without being self-critical.",
      ]},
    { name: "Extending", band: "Extending on the essay rubric",
      text: [
        "In September I wrote \u201CThis essay is about my grandmother\u201D and thought I had started.",
        "What I did not know was that the reader had already left. An announcement gives the reader the map before the journey, and a map without a journey is just paper. It took until Unit 5 to learn that an opening is not a label. It is the moment before the reader knows where they are going, and if it works, they go.",
        "The harder lesson was the defence. In Unit 8 I wrote that I chose narrative because I liked it, and I believed that was a reason. It is not. A defence is about the reader, not the writer. My Unit 9 defence says the reader should feel the moment before they judge it, and it names what an essay would have taken away. I could not have written that sentence in October.",
        "My endings are still the weakest part of everything I write. The last line of my Unit 9 essay explains what the piece already showed, and I know it, and I left it because I did not trust the reader to get there alone. That is the next skill: trusting the reader. It is the one I have not earned yet, and I can see it every time I reach for the explanation instead of the image.",
      ],
      why: [
        "Opens on the exact September line, not a summary. The reader sees the start immediately.",
        "The insight goes beyond naming the skill: \u201Ca map without a journey is just paper\u201D is a claim about why the skill matters.",
        "\u201CI could not have written that sentence in October\u201D is a measure of distance, not just a list of changes.",
        "The weakness is named with evidence AND with the cause (\u201CI did not trust the reader\u201D), and the next step is the specific skill that would fix it. Self-knowledge at Extending.",
      ]},
  ],
  comparison: [
    ["Evidence", "None; general claims only", "Pointed: specific units, specific lines", "Pointed, and the evidence carries insight beyond the skill itself"],
    ["Before/after", "No before shown", "Clear before-and-after pairs", "Before quoted; the distance between them is measured, not just named"],
    ["Weakness", "None named", "Named with evidence and a next step", "Named with evidence, a cause, and a next step that addresses the cause"],
    ["Tone", "Performed gratitude", "Candid and specific", "Candid, specific, and self-aware without being self-critical"],
    ["Insight", "None beyond \u201CI learned a lot\u201D", "Names what changed and why", "Names what changed, why it matters, and what the change cost"],
  ],
};

const NOTEBOOK = {
  title: "The Portfolio Notebook",
  subtitle: "One running record across the whole unit \u00B7 four checkpoints \u00B7 20 percent of the unit",
  intro: "This is the spine of the unit. It runs from Lesson 1 to Lesson 12 and carries three things: your inventory of the year\u2019s work, your annotations explaining why each selected piece matters, and your final reflection proving your growth with evidence. The portfolio is the product; the Notebook is the record of how you built it.",
  howItWorks: [
    "Lesson 1: a full inventory of every piece from every unit, marked strong, weak, or uncertain.",
    "Lessons 2\u20135: annotations for each selected piece (name the skill, point to where it shows) and your final sequence.",
    "Lesson 3 adds the shape of the year: your biggest leap, your longest plateau, and one turning point with its cause.",
    "Lessons 6\u20139: drafting notes as you write and revise the reflective essay.",
    "Lesson 12: the final reflection, which is what the Notebook is marked on.",
  ],
  checkpoints: [
    ["Checkpoint 1","Lesson 3","Inventory complete, year shape mapped (leap, plateau, turning point with causes). I check that causes are named, not just moments."],
    ["Checkpoint 2","Lesson 6","Portfolio pieces selected and annotated, reflective essay opening drafted. I check that annotations name skills and point to evidence."],
    ["Checkpoint 3","Lesson 9","Reflective essay fully drafted and revised. I check that every claim has pointed evidence and the ending is honest."],
    ["Checkpoint 4","Lesson 12","Final reflection. This is the part that is marked."],
  ],
  exampleEntries: [
    ["Inventory \u2014 weak","Unit 5: essay. Good.","Names no skill, gives no reason. \u201CGood\u201D is not a judgment that helps you select."],
    ["Inventory \u2014 strong","Unit 5: narrative essay [S]. Opens on a moment, not a topic. First piece where I stopped announcing.","Names the skill (opening on a moment), marks it strong, and gives a reason that would survive questioning."],
    ["Annotation \u2014 strong","This piece shows I can defend a form. Compare my Unit 8 admission (\u201CI chose narrative because I like it\u201D) to this Unit 9 defence, which names the reader effect. The change is in the reason, not the choice.","Points to both before and after, names the specific skill, and explains what changed."],
  ],
  finalTask: "In Lesson 12 you write the reflection the Notebook is marked on. It answers three things, each with evidence from your portfolio: what you can do now that you could not in September (point to where), what is still hard (point to where it shows), and what comes next (name the skill). \u201CI improved\u201D is a claim. \u201CMy Unit 2 opening announced; my Unit 9 opening placed the reader in a room\u201D is proof.",
  rubricIntro: "The Portfolio Notebook is worth 20 percent of the unit. It is assessed on the Lesson 12 reflection, not on the number of entries or the number of pieces in the portfolio. A full Notebook with a thin reflection does not score well; the entries are the condition, the reflection is the criterion.",
  rubricRows: [
    ["Emerging","The reflection describes feelings about the year rather than naming skills, and points to no specific place in the work."],
    ["Developing","Names one skill that changed but supports it thinly, with a general claim rather than a pointed place in the portfolio."],
    ["Proficient","Names what they can do now and what is still hard, each pointed to a specific piece in their portfolio as proof."],
    ["Extending","Adds a next step and a claim about themselves as a reader/writer \u2014 tied to a specific cause \u2014 that they could not have made in September."],
  ],
};

module.exports = { EXEMPLARS, NOTEBOOK };
