const INTRO = {
  title: "Your last unit of ELL 3",
  sections: [
    { h: "What this unit is", p: "This is the end of the year. You will gather your work from every unit, choose the pieces that prove your growth, write a reflective essay showing what changed and what is still hard, and sit with your teacher for a conference about your year and your next step." },
    { h: "The three parts", p: "First, a portfolio: five to seven pieces selected and annotated from across the course. Second, a reflective essay that claims, proves, and admits, all with evidence from your own work. Third, a student-teacher conference where you present your portfolio, hear a placement recommendation, and respond." },
    { h: "How your mark is made", p: "The reflective essay carries the most weight, then the conference, then the Portfolio Notebook. There is a short unit test as well, but it is light. Most of your mark comes from the work you have been building all year, judged on how honestly and specifically you can account for it." },
    { h: "If you join partway through", p: "Start where the class is. You may have fewer units to draw from, but every piece of work you have is evidence. A smaller portfolio with strong annotations is better than a large one with weak ones." },
  ],
};

const PARENT_LETTER = {
  greeting: "Dear parent or guardian,",
  intro: "This month your student completes the final unit of ELL 3 Language Strategies. They will look back across the whole year, select their best work, and write a reflective essay proving their growth with evidence from their own writing. The unit ends with a one-on-one student-teacher conference where we discuss their year, their strengths, what they are still working on, and a placement recommendation for September.",
  bullets: [
    ["A portfolio of their best work", "Your student chooses five to seven pieces from across the year and writes a note for each explaining what it proves about their growth. The choosing is itself a skill: it takes real judgment to know which work represents you."],
    ["A reflective essay with evidence", "Rather than simply saying they improved, your student must point to specific places in specific pieces that show the change. This is the same standard of evidence we have taught all year, now turned on their own work."],
    ["A student-teacher conference", "Every student sits one-on-one with their teacher to talk through their portfolio, their reflection, and their next step. They will also hear a placement recommendation for next year. If your student wants to discuss the recommendation with you, please ask them to show you the portfolio and the essay \u2014 the evidence is all there."],
    ["What you can do", "Ask your student to walk you through their portfolio before the conference. Being able to explain their own growth to someone other than their teacher is excellent preparation."],
  ],
  close: "Thank you for supporting your student's learning this year. If you have questions about the placement recommendation, please contact me after the conference.",
  sign: "Mr. Reid",
};

const SCALE = {
  note: "Work in this unit is reported on the District ELL proficiency scale. The four levels describe how fully a piece meets the criterion; they are not percentages.",
  levels: [
    ["Emerging","Beginning to show the skill, with support; the piece attempts the task but does not yet meet it."],
    ["Developing","The skill is present but uneven; the piece meets some of the criterion and misses parts."],
    ["Proficient","The skill is consistently present; the piece meets the criterion clearly and independently."],
    ["Extending","The skill is secure and used with control; the piece goes beyond the criterion in a way that shows real command."],
  ],
};

const RUBRIC = {
  intro: "The essay rubric marks the reflective essay. It is separate from the unit test and from the conference.",
  levels: ["Emerging","Developing","Proficient","Extending"],
  criteria: [
    { name: "Claims proven", rows: [
      "Claims are made but none are supported with pointed evidence from the portfolio.",
      "Some claims are supported; others remain general or unpointed.",
      "Every claim names a skill and points to a specific before-and-after in the portfolio.",
      "Claims carry insight beyond the skill itself \u2014 the writer explains why the change matters.",
    ]},
    { name: "Honest ending", rows: [
      "The ending claims everything is resolved, or thanks the teacher, or names no weakness.",
      "A weakness is named but without evidence, or the next step is a feeling rather than a skill.",
      "The ending names a real weakness with evidence and sets a next step that names a skill.",
      "The weakness is named with its cause, and the next step addresses that cause specifically.",
    ]},
    { name: "Structure", rows: [
      "The essay is a list of things learned, with no clear before-and-after structure.",
      "Some paragraphs follow the before-and-after pattern; others drift or repeat.",
      "Each body paragraph picks one skill, names the before, names the after, and transitions clearly.",
      "The structure tells the story of the year; transitions carry the reader through the timeline.",
    ]},
    { name: "Voice and tone", rows: [
      "The tone is performed (gratitude, triumph) rather than candid.",
      "Mostly candid but slips into performance in places.",
      "Candid throughout; the voice sounds like the writer, not like a speech.",
      "The voice is assured and self-aware; the writer writes about writing with real authority.",
    ]},
    { name: "Control", rows: [
      "Errors in sentences or word choice often get in the reader's way.",
      "Sentences and word choice are mostly clear, with some lapses.",
      "Sentences are controlled and word choice is purposeful.",
      "Sentence length and word choice are used for effect, not only correctness.",
    ]},
  ],
};

const ORAL_RUBRIC = {
  intro: "The conference rubric marks the one-on-one student-teacher conference. It is separate from the essay and from the unit test.",
  levels: ["Emerging","Developing","Proficient","Extending"],
  criteria: [
    { name: "Prepared", rows: [
      "Arrives without portfolio or notes; cannot name a starting point.",
      "Has the portfolio but has not prepared specific points to cover.",
      "Arrives with portfolio open and three prepared points (evidence, weakness, next step).",
      "Prepared and flexible \u2014 adjusts to the teacher's questions without losing the thread.",
    ]},
    { name: "Evidence used", rows: [
      "Talks about growth in general terms; does not point to the portfolio.",
      "Points to one or two pieces but without naming a specific skill or place.",
      "Points to specific before-and-after pieces and names the skill each one proves.",
      "Uses the portfolio fluently, turning to the right page and quoting the evidence.",
    ]},
    { name: "Honesty", rows: [
      "Claims only strengths; does not name what is still hard.",
      "Names a weakness in general terms without evidence.",
      "Names a specific weakness, points to where it shows, and sets a next step.",
      "The weakness discussion shows real self-knowledge and a cause, not just a label.",
    ]},
    { name: "Response", rows: [
      "Does not respond to the placement recommendation; nods or stays silent.",
      "Responds but without a reason or evidence.",
      "Responds with a reason tied to the portfolio; asks a real follow-up question if unsure.",
      "Engages with the recommendation as a genuine conversation, advocating with evidence.",
    ]},
  ],
};

const TEST_LETTER = {
  title: "The Folder and the Portfolio",
  author: "A short essay you have not seen before. Read it twice, then answer Section B.",
  paras: [
    "My cousin keeps everything she has ever written in a box under her bed. She has seven years of school work in there, and she can find none of it, and she has never gone back to read any of it.",
    "I asked her once if she knew what was in the box. She said everything. I asked her which piece was her best. She said she did not know because she had not looked.",
    "A box that holds everything and has never been opened is not a record. It is a burial. The work is in there the way a letter is in a bottle thrown off a dock: it exists, but no one will ever read it, including the person who wrote it.",
    "A portfolio is the opposite of that box. Not because it holds less, but because someone chose what went in and could tell you why.",
  ],
};

const PRACTICE = {
  time: "40 minutes", seed: 101,
  sections: [
    { id:"A", title:"Reflection vocabulary", marks:4, kind:"match",
      instr:"Match each word to its meaning. Write the letter beside the number.",
      terms: [
        ["portfolio","a collection of your work chosen to show your abilities"],
        ["annotation","a note explaining why a piece is in the portfolio"],
        ["evidence","proof you can point to"],
        ["candid","open and honest, not hiding the hard parts"],
      ]},
    { id:"B", title:"Claims and evidence", marks:4, kind:"short",
      instr:"Answer each in a sentence.",
      items: [
        {q:"What is the difference between a claim and evidence?",a:"A claim states something is true; evidence points to a specific place that proves it.",lines:2},
        {q:"Why is a before-and-after pair stronger than a single good piece?",a:"A pair proves change over time; a single piece only proves current ability.",lines:2},
        {q:"What makes an honest ending stronger than one that claims everything is resolved?",a:"Growth does not stop; naming what is still hard is more believable and shows self-knowledge.",lines:2},
        {q:"What should an annotation name that \u201Cthis is my best work\u201D does not?",a:"A specific skill and where it shows in the piece.",lines:2},
      ]},
    { id:"C", title:"Writing \u2014 annotate a piece", marks:12, kind:"write",
      instr:"Read the situation, then write your answer.",
      passage:"A student includes their Unit 5 essay in their portfolio. The essay opens on a grandmother standing at a window. Write an annotation for this piece that names the skill it demonstrates, points to where it shows, and compares it to an imagined earlier piece where that skill was missing.",
      a:"A strong annotation names the skill (e.g. opening on a moment), points to the specific line (grandmother at the window), and contrasts it with an earlier piece that opened differently.",
      lines:10 },
  ],
};

const UNITTEST = {
  time: "45 minutes", seed: 102,
  sections: [
    { id:"A", title:"Reflection vocabulary", marks:4, kind:"match",
      instr:"Match each word to its meaning. Write the letter beside the number.",
      terms: [
        ["reflect","to look back and draw meaning from what you did"],
        ["curate","to select and arrange with purpose"],
        ["advocate","to speak up for yourself with reasons"],
        ["trajectory","the path something follows over time"],
      ]},
    { id:"B", title:"Reading \u2014 The Folder and the Portfolio", marks:4, kind:"short", useTestLetter:true,
      instr:"Answer each in a sentence. Give a line number where the question asks for one.",
      items: [
        {q:"What does the cousin keep, and what is wrong with how she keeps it?",a:"Everything she has written, in a box under her bed; she has never opened it or looked at any of it.",lines:2},
        {q:"The writer says a box that holds everything and has never been opened is \u201Cnot a record\u201D but \u201Ca burial.\u201D What does this comparison mean?",a:"The work is hidden and forgotten, not preserved; keeping everything without choosing is the same as losing it.",lines:2},
        {q:"What does the writer say makes a portfolio the opposite of the box? Point to the line.",a:"Someone chose what went in and could tell you why (paragraph 4).",lines:2},
        {q:"This essay is making a claim about portfolios. What is the claim, and does the box example prove it?",a:"The claim is that choosing is what makes a portfolio valuable, not the quantity; the box proves it by showing what holding-everything-without-choosing looks like.",lines:2},
      ]},
    { id:"C", title:"Writing \u2014 reflect on one skill", marks:12, kind:"write",
      instr:"Read the situation, then write your answer.",
      passage:"Think of one skill you learned or improved this year in ELL 3. Write a short reflective paragraph that names the skill, shows a before (what you could not do earlier) and an after (what you can do now), and names one thing that is still hard about it.",
      a:"A strong answer names a specific skill, points to a before and an after, and names a real weakness \u2014 not a general feeling.",
      lines:12 },
  ],
};

const PLAN_DETAIL = {
  duration: "One 75-minute block (or two shorter periods).",
  common: {
    materials: "Slide deck, lesson worksheet, the student's Portfolio Notebook, and all returned work from Units 1\u20139. Lesson 4 also needs the mentor reflective essay. Lesson 11 is the conference itself.",
    differentiation: "The unit is self-levelling: students select from their own work and reflect at their own depth. Support students by helping them find their work (some will have lost pieces) and by modelling the annotation format. Extension comes from the depth and honesty of the reflection, not from extra pieces.",
  },
  perLesson: {
    1:  {hw:"Bring every piece of work you still have from this year to the next lesson.",watch:"Watch for students who have lost work. Help them find what they have rather than what they do not."},
    2:  {hw:"Complete annotations for your three chosen pieces.",watch:"Watch for annotations that say \u201Cthis is good\u201D without naming a skill or a place."},
    3:  {hw:"Finish the year map in the Portfolio Notebook (Checkpoint 1).",watch:"Watch for leaps named without causes. Push for the why, not just the when."},
    4:  {hw:"Note two craft moves from the model essay you will borrow.",watch:"Watch for students copying the model\u2019s content rather than its structure."},
    5:  {hw:"Finalize your portfolio selection and sequence.",watch:"Watch for portfolios that are all one kind of piece. Push for range."},
    6:  {hw:"Draft the opening of the reflective essay.",watch:"Watch for openings that start with \u201CThis year I learned.\u201D Push for a specific September moment."},
    7:  {hw:"Draft the body paragraphs.",watch:"Watch for paragraphs that describe rather than prove. Each needs a pointed before-and-after."},
    8:  {hw:"Draft the ending.",watch:"Watch for endings that perform gratitude. Push for an honest weakness with evidence."},
    9:  {hw:"Revise the full essay against the rubric (Checkpoint 3).",watch:"Watch for claims without pointed evidence. That is the single most common gap."},
    10: {hw:"Prepare three conference notes and mark the portfolio piece to open on.",watch:"Watch for scripts. Notes should be prompts, not sentences."},
    11: {hw:"None \u2014 conference day.",watch:"Record evidence for each student. Ask one follow-up question per conference."},
    12: {hw:"None \u2014 the course is complete.",watch:"Watch that the final reflection proves its claims. Guard against it becoming a thank-you note."},
  },
};

module.exports = { INTRO, PARENT_LETTER, SCALE, RUBRIC, ORAL_RUBRIC, PRACTICE, UNITTEST, PLAN_DETAIL, TEST_LETTER };
