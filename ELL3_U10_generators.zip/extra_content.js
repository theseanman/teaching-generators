const MODEL = { title: "What I Did Not Know I Was Learning (studied closely in Lesson 4)", note: "", paras: [] };
const EXEMPLARS = null;
module.exports = { MODEL, EXEMPLARS };
